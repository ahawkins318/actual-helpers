import { send } from '@actual-app/core/platform/client/connection';
import type { InitConfig } from '@actual-app/core/server/main';
export * from './methods';
export * as utils from './utils';
export declare function init(config?: InitConfig): Promise<{
    send: typeof send;
}>;
export declare function shutdown(): Promise<void>;
//# sourceMappingURL=index.browser.d.ts.map