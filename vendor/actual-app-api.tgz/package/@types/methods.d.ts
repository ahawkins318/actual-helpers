import type { APIAccountEntity, APICategoryEntity, APICategoryGroupEntity, APIFileEntity, APIPayeeEntity, APIScheduleEntity, APITagEntity } from '@actual-app/core/server/api-models';
import type { ImportableBudgetType } from '@actual-app/core/server/importers/index';
import type { Query } from '@actual-app/core/shared/query';
import type { ImportTransactionsOpts } from '@actual-app/core/types/api-handlers';
import type { ImportTransactionEntity, NoteEntity, RuleEntity, TransactionEntity } from '@actual-app/core/types/models';
import type { SyncedPrefs } from '@actual-app/core/types/prefs';
export { q } from './app/query';
export declare function runImport(budgetName: APIFileEntity['name'], func: () => Promise<void>): Promise<void>;
export declare function loadBudget(budgetId: string): Promise<void>;
export declare function downloadBudget(syncId: string, { password }?: {
    password?: string;
}): Promise<void>;
export declare function getBudgets(): Promise<APIFileEntity[]>;
/**
 * Import a budget from an exported file — an Actual `.zip` export, or a
 * YNAB4/YNAB5 export. Accepts either a path to the file on the engine's
 * filesystem, or the raw file contents. Loads the imported budget and
 * returns its id.
 */
export declare function importBudget(input: string | ArrayBuffer | Uint8Array, { type, filename }?: {
    type?: ImportableBudgetType;
    filename?: string;
}): Promise<{
    id: string;
}>;
/** Export the currently-loaded budget as a zip buffer. */
export declare function exportBudget(): Promise<Uint8Array>;
export declare function sync(): Promise<void>;
export declare function runBankSync(args?: {
    accountId: APIAccountEntity['id'];
}): Promise<void>;
export declare function batchBudgetUpdates(func: () => Promise<void>): Promise<void>;
/**
 * @deprecated Please use `aqlQuery` instead.
 * This function will be removed in a future release.
 */
export declare function runQuery(query: Query): Promise<unknown>;
export declare function aqlQuery(query: Query): Promise<unknown>;
export declare function getBudgetMonths(): Promise<string[]>;
export declare function getBudgetMonth(month: string): Promise<{
    month: string;
    incomeAvailable: number;
    lastMonthOverspent: number;
    forNextMonth: number;
    totalBudgeted: number;
    toBudget: number;
    fromLastMonth: number;
    totalIncome: number;
    totalSpent: number;
    totalBalance: number;
    categoryGroups: Array<Record<string, unknown> & {
        categories?: Record<string, unknown>[];
    }>;
}>;
export declare function setBudgetAmount(month: string, categoryId: APICategoryEntity['id'], value: number): Promise<void>;
export declare function setBudgetCarryover(month: string, categoryId: APICategoryEntity['id'], flag: boolean): Promise<void>;
export declare function addTransactions(accountId: APIAccountEntity['id'], transactions: Omit<ImportTransactionEntity, 'account'>[], { learnCategories, runTransfers }?: {
    learnCategories?: boolean;
    runTransfers?: boolean;
}): Promise<"ok">;
export declare function importTransactions(accountId: APIAccountEntity['id'], transactions: ImportTransactionEntity[], opts?: ImportTransactionsOpts): Promise<import("@actual-app/core/server/accounts/sync").ReconcileTransactionsResult & {
    errors: Array<{
        message: string;
    }>;
}>;
export declare function getTransactions(accountId: APIAccountEntity['id'], startDate: string, endDate: string): Promise<TransactionEntity[]>;
export declare function updateTransaction(id: TransactionEntity['id'], fields: Partial<TransactionEntity>): Promise<TransactionEntity[] | ({
    id: any;
    transfer_id: any;
} | {
    id: any;
    category: any;
})[]>;
export declare function deleteTransaction(id: TransactionEntity['id']): Promise<TransactionEntity[]>;
export declare function getAccounts(): Promise<APIAccountEntity[]>;
export declare function createAccount(account: Omit<APIAccountEntity, 'id'>, initialBalance?: number): Promise<string>;
export declare function updateAccount(id: APIAccountEntity['id'], fields: Partial<APIAccountEntity>): Promise<void>;
export declare function closeAccount(id: APIAccountEntity['id'], transferAccountId?: APIAccountEntity['id'], transferCategoryId?: APICategoryEntity['id']): Promise<void>;
export declare function reopenAccount(id: APIAccountEntity['id']): Promise<void>;
export declare function deleteAccount(id: APIAccountEntity['id']): Promise<void>;
export declare function getAccountBalance(id: APIAccountEntity['id'], cutoff?: Date): Promise<number>;
export declare function getCategoryGroups(options?: {
    hidden?: boolean;
}): Promise<APICategoryGroupEntity[]>;
export declare function createCategoryGroup(group: Omit<APICategoryGroupEntity, 'id'>): Promise<string>;
export declare function updateCategoryGroup(id: APICategoryGroupEntity['id'], fields: Partial<APICategoryGroupEntity>): Promise<void>;
export declare function deleteCategoryGroup(id: APICategoryGroupEntity['id'], transferCategoryId?: APICategoryEntity['id']): Promise<void>;
export declare function getCategories(options?: {
    hidden?: boolean;
}): Promise<APICategoryEntity[]>;
export declare function createCategory(category: Omit<APICategoryEntity, 'id'>): Promise<string>;
export declare function updateCategory(id: APICategoryEntity['id'], fields: Partial<APICategoryEntity>): Promise<void>;
export declare function deleteCategory(id: APICategoryEntity['id'], transferCategoryId?: APICategoryEntity['id']): Promise<void>;
export declare function getNote(id: NoteEntity['id']): Promise<NoteEntity | null>;
export declare function updateNote(id: NoteEntity['id'], note: NoteEntity['note']): Promise<void>;
export declare function getCommonPayees(): Promise<APIPayeeEntity[]>;
export declare function getPayees(): Promise<APIPayeeEntity[]>;
export declare function createPayee(payee: Omit<APIPayeeEntity, 'id'>): Promise<string>;
export declare function updatePayee(id: APIPayeeEntity['id'], fields: Partial<APIPayeeEntity>): Promise<void>;
export declare function deletePayee(id: APIPayeeEntity['id']): Promise<void>;
export declare function getTags(): Promise<APITagEntity[]>;
export declare function createTag(tag: Omit<APITagEntity, 'id'>): Promise<string>;
export declare function updateTag(id: APITagEntity['id'], fields: Partial<Omit<APITagEntity, 'id'>>): Promise<void>;
export declare function deleteTag(id: APITagEntity['id']): Promise<void>;
export declare function mergePayees(targetId: APIPayeeEntity['id'], mergeIds: APIPayeeEntity['id'][]): Promise<void>;
export declare function getRules(): Promise<RuleEntity[]>;
export declare function getPayeeRules(id: RuleEntity['id']): Promise<RuleEntity[]>;
export declare function createRule(rule: Omit<RuleEntity, 'id'>): Promise<{
    id: string;
} & import("@actual-app/core/types/models").NewRuleEntity>;
export declare function updateRule(rule: RuleEntity): Promise<{
    id: string;
} & import("@actual-app/core/types/models").NewRuleEntity>;
export declare function deleteRule(id: RuleEntity['id']): Promise<boolean>;
export declare function holdBudgetForNextMonth(month: string, amount: number): Promise<boolean>;
export declare function resetBudgetHold(month: string): Promise<void>;
export declare function createSchedule(schedule: Omit<APIScheduleEntity, 'id'>): Promise<string>;
export declare function updateSchedule(id: APIScheduleEntity['id'], fields: Partial<APIScheduleEntity>, resetNextDate?: boolean): Promise<string>;
export declare function deleteSchedule(scheduleId: APIScheduleEntity['id']): Promise<void>;
export declare function getSchedules(): Promise<APIScheduleEntity[]>;
export declare function getIDByName(type: 'accounts' | 'schedules' | 'categories' | 'payees', name: string): Promise<string>;
export declare function getServerVersion(): Promise<{
    error: 'no-server';
} | {
    error: 'network-failure';
} | {
    version: string;
}>;
/** Read the budget's synced preferences (number format, currency, etc.). */
export declare function getPreferences(): Promise<SyncedPrefs>;
//# sourceMappingURL=methods.d.ts.map